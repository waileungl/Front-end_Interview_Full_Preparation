

// Example to handle a returned promise
const promise = createAudioFileAsync(audioSettings); 
promise.then(successCallback, failureCallback);